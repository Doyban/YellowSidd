var YellowSidd = YellowSidd || {};

YellowSidd.Upgrade = function (game_state) {
  "use strict";
  this.game_state = game_state; // Save game state.
};

YellowSidd.Upgrade.prototype.apply = function () {
  "use strict";
};